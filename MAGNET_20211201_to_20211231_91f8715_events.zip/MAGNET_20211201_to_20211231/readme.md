No Feature Processor has been created for this game - Get involved here!
https://github.com/fielddaylab/opengamedata

## Field Day Open Game Data  
### Retrieved from https://fielddaylab.wisc.edu/opengamedata  
### These anonymous data are provided in service of future educational data mining research.  
### They are made available under the Creative Commons CCO 1.0 Universal license.  
### See https://creativecommons.org/publicdomain/zero/1.0/  

## Suggested citation:  
### Field Day. (2019). Open Educational Game Play Logs - [dataset ID]. Retrieved [today's date] from https://fielddaylab.wisc.edu/opengamedata  

# Game: MAGNET  

## Field Descriptions:  

## Database Columns  

The individual columns recorded in the database for this game.  

**id** : *int* - Row ID, Unique identifier for a row  
**app_id** : *str* - App Name, A string identifying which game from which the event came  
**app_id_fast** : *enum('UNDEFINED','WAVES','CRYSTAL','JOWILDER','LAKELAND')* - app_id_fast, A second version of the app id, to be removed  
**app_version** : *int* - App Version, The version of the game from which the event came  
**session_id** : *str* - Session ID, Unique identifier for the gameplay session  
**persistent_session_id** : *str* - Persistent Session ID, Unique identifier across all gameplay sessions from a single computer  
**player_id** : *str* - Player ID, A custom, per-player ID, only exists if player entered an ID on one of our custom portal pages, else null  
**level** : *int* - Level, The game level in which the event was logged  
**event** : *enum('BEGIN','COMPLETE','SUCCEED','FAIL','CUSTOM','UNDEFINED')* - Event Type, The type of event logged  
**event_custom** : *str* - Event Subtype, A number corresponding to the game-specific event type for events labeled 'Custom'  
**event_data_simple** : *str* - event_data_simple, Unused (always=0), to be deleted  
**event_data_complex** : *json* - Event Data, Data specific to an event type, encoded as a JSON string  
**client_time** : *datetime* - Client Time, The client machine time when the event was generated  
**client_time_ms** : *int* - Client Time Milliseconds, Number of milliseconds to append to client time  
**server_time** : *datetime* - Server Time, The server machine time when the event was logged  
**remote_addr** : *str* - IP Address, The IP address for the player's computer  
**req_id** : *int* - req_id, Another ID of some kind, to be removed  
**session_n** : *int* - Event-Sequence Index, Counter of events in the session, from 0. A row with session_n = i is the (i+1)-th event of the session  
**http_user_agent** : *str* - User Agent, Data on the type of web browser, OS, etc. in use by the player  

## Event Object Elements  

The elements (member variables) of each Event object, available to programmers when writing feature extractors. The right-hand side shows which database column(s) are mapped to a given element.  

**session_id** = Column '*session_id*'  
**app_id** = Column '*app_id*'  
**timestamp** = Columns '*client_time*', '*client_time_ms*'  
**event_name** = Columns '*event*', '*event_custom*'  
**event_data** = Columns '*event_data_complex*', '*server_time*', '*level*', '*persistent_session_id*', '*remote_addr*', '*http_user_agent*'  
**app_version** = Column '*app_version*'  
**time_offset** = null  
**user_id** = Column '*player_id*'  
**user_data** = null  
**game_state** = null  
**event_sequence_index** = Column '*session_n*'  

## Event Types  

The individual fields encoded in the *event_data* Event element for each type of event logged by the game.  

**COMPLETE**:  
- **guessScore**: {'northDist': 'float', 'southDist': 'float'}  
- **guessScoreIfSwitched**: {'northPoleToSouthGuess': 'float', 'southPoleToNorthGuess': 'float'}  
- **numCompasses**: int  
- **ironFilingsUsed**: boolean  
- **magneticFilmUsed**: boolean  
- **levelTime**: float  
- **numLevels**: int  
- **numTimesPolesMoved**: int  
- **magnetLocation**: {'xNorth': 'float', 'yNorth': 'float', 'xSouth': 'float', 'ySouth': 'float'}  
- **event_custom**: COMPLETE  

**DRAG_TOOL**:  
- **event_custom**: DRAG_TOOL  
- **toolType**: string  
- **dragTime**: float  
- **location**: {'x': 'int', 'y': 'int'}  
- **toolNum**: float  

**DRAG_POLE**:  
- **event_custom**: DRAG_POLE  
- **poleType**: string  
- **dragTime**: float  
- **location**: {'x': 'int', 'y': 'int'}  
- **numTimesMoved**: int  
- **distToPole**: float  
- **numToolsUsed**: int  

**PLAYGROUND_EXIT**:  
- **event_custom**: PLAYGROUND_EXIT  
- **timeSpent**: float  
- **numThingsDragged**: int  

**TUTORIAL_EXIT**:  
- **event_custom**: TUTORIAL_EXIT  
- **timeSpent**: float  

## Processed Features  

The features/metrics calculated from this game's event logs by OpenGameData when an 'export' is run.  

**eventCount** : *Unknown*, *perlevel feature*   
Number of player events in the given level  

**southPoleScore** : *Unknown*, *perlevel feature*   
The score for the south pole placement  

**northPoleScore** : *Unknown*, *perlevel feature*   
The score for the north pole placement  

**northPoleToSouthGuess** : *Unknown*, *perlevel feature*   
The score for the south pole placement if the poles were switched.  

**southPoleToNorthGuess** : *Unknown*, *perlevel feature*   
The score for the north pole placement if the poles were switched.  

**numberOfCompassesUsed** : *Unknown*, *perlevel feature*   
How many of the six compasses were placed before guessing  

**usedMagneticFilm** : *Unknown*, *perlevel feature*   
Indicates whether the magnetic film was placed  

**usedIronFilings** : *Unknown*, *perlevel feature*   
Indicates whether the iron filings were placed  

**numTimesPolesMoved** : *Unknown*, *perlevel feature*   
The number of times the poles were moved before finalizing the guess  

**levelTime** : *Unknown*, *perlevel feature*   
The amount of time spent in the level  

**sessionID** : *Unknown*, *aggregate feature*   
The player's session ID number for this play session  

**persistentSessionID** : *Unknown*, *aggregate feature*   
The session ID for the player's device, persists across multiple players using the same device.  

**sessionEventCount** : *Unknown*, *aggregate feature*   
The total number of events across the entire session  

**sessionTime** : *Unknown*, *aggregate feature*   
The total number of seconds spent  

**numberOfCompletePlays** : *Unknown*, *aggregate feature*   
The number of times the player played the game  

**averageScore** : *Unknown*, *aggregate feature*   
The average score across all complete plays  

## Global Database Changelog:
### August 2019:
- Added remote_addr field to raw csv
- Duplicated events may exist in data prior to August 21, 2019.